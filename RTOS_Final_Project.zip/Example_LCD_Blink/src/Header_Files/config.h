/*
 * config.h
 *
 *  Created on: Nov 12, 2021
 *      Author: ivanr
 */

#ifndef CONFIG_H
#define CONFIG_H

#define VERSION                   2

#define GRAVITY                   -6000 // mm/s^2
#define VEHICLE_MASS              70000 // kg
#define GRAPH_XLIM                128
#define GRAPH_YLIM                128
#define OPTION                    0 // not implemented
#define MAX_THRUST                400 // Newtons
#define INTL_FUEL_MASS            2400 // initial fuel mass in kilograms
#define CONVERSION_EFFICIENCY     4000 // %
// #define FUEL_ENERGY_DENSITY       // Removed in version 2
#define MAX_VERT_SPEED            -65000 // arbitrary values that were playable
#define MAX_HOR_SPEED             65000  // ^^
#define BLACKOUT_VELO           -40000   // ^^
#define BLACKOUT_DUR              2     // seconds
#define INTL_VELO_X               0 // cm/s
#define INTL_VELO_Y               -5000 // cm/s
#define INTL_HOR_POSITION         128 / 2 // mm
#define ANGLE_CHANGE_QUANTA       45 // mrad (angle for now)
// #define ANGLE_RATE_CHANGE         // Not relevant to implementation
#define MAX_VERT_LANDING_SPEED         -25000
#define MAX_HOR_LANDING_SPEED           25000

#endif /* CONFIG_H */
