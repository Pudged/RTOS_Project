/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef TASKS_H
#define TASKS_H

#include "gpio.h"

#define LCD_TASK_STACK_SIZE         512
#define LCD_TASK_PRIO               5

#define ANGLE_TASK_STACK_SIZE       512
#define ANGLE_TASK_PRIO             1

#define THRUST_TASK_STACK_SIZE      512
#define THRUST_TASK_PRIO            2

#define PHYSICS_TASK_STACK_SIZE     512
#define PHYSICS_TASK_PRIO           4

#define LED0_TASK_STACK_SIZE        512
#define LED0_TASK_PRIO              3

#define LED1_TASK_STACK_SIZE       512
#define LED1_TASK_PRIO             3

#define IDLE_TASK_STACK_SIZE        512
#define IDLE_TASK_PRIO              6

// enum for ship angles.
typedef enum
{
  straight_up,
  left,
  hard_left,
  right,
  hard_right
} ship_angle;

// Data structure for ship angle
typedef struct
{
  ship_angle current_angle;
} angle_data_t;

// Data structure for thrust data
typedef struct
{
  int thrust_value;
  int x_pos;
  int y_pos;
  double x_velo;
  double y_velo;
  double fuel_mass;
  bool blackout;
  int blackout_time;

} thrust_data_t;

/***************************************************************************//**
 * Functions Protos
 ******************************************************************************/
void tasks_init(void);
void angle_timerCallback(void *p_tmr, void *p_arg);
int set_thrust(int button0, int button1);
ship_angle set_angle(int position);
bool check_endgame();
double map(float x, float in_min, float in_max, float out_min, float out_max);
int find_posQuanta(double velocity);

#endif  // TASKS_H
