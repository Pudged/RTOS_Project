/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

//#include "sl_simple_led.h"
//#include "sl_simple_led_instances.h"
#include "os.h"
#include "tasks.h"
#include "glib.h"
#include "dmd.h"
#include "em_emu.h"
#include "gpio.h"
#include "config.h"
#include "capsense.h"
#include "stdio.h"

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB lcd_tcb;
static CPU_STK lcd_stack[LCD_TASK_STACK_SIZE];

static OS_TCB angle_tcb;
static CPU_STK angle_stack[ANGLE_TASK_STACK_SIZE];
static OS_MUTEX angle_mutex;
static OS_TMR angle_timer;
static OS_SEM angle_timer_semaphore;

static OS_TCB thrust_tcb;
static CPU_STK thrust_stack[THRUST_TASK_STACK_SIZE];
static OS_MUTEX thrust_mutex;

static OS_TCB physics_tcb;
static CPU_STK physics_stack[PHYSICS_TASK_STACK_SIZE];
static OS_TMR physics_timer;
static OS_SEM physics_timer_semaphore;

static OS_TCB led0_tcb;
static CPU_STK led0_stack[LED0_TASK_STACK_SIZE];


static OS_TCB led1_tcb;
static CPU_STK led1_stack[LED1_TASK_STACK_SIZE];
static OS_TMR led1_timer;
static OS_SEM led1_timer_semaphore;
static OS_TMR led1_oneshot_timer;

static OS_TCB idle_tcb;
static CPU_STK idle_stack[IDLE_TASK_STACK_SIZE];

static OS_FLAG_GRP btn_event_flag_grp;
static GLIB_Context_t glibContext;
//static int currentLine = 0;

static thrust_data_t thrust_data;
static angle_data_t angle_data;

unsigned int button0 = 1;
unsigned int button1 = 1;
int32_t position;
static int time = 0;
static int current_thrust = 0;
static bool gameFlag = false;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void lcd_task(void *arg);
static void angle_task(void *arg);
static void thrust_task(void *arg);
static void physics_task(void *arg);
static void led0_task(void *arg);
static void led1_task(void *arg);
static void idle_task(void *arg);

/**
 * @brief GPIO IRQ Handler
 * Interrupt Service Routine for all GPIO pins
 * Currently used by both odd and even pin IRQ handlers
 */
void GPIO_IRQHandler(void)
{
    uint32_t int_flag = GPIO->IF & GPIO->IEN;
    GPIO->IFC = int_flag;
    uint8_t event = 0x0;

    if (int_flag & 0x80){
        event |= 0x2;
    }

    if (int_flag & 0x40){
        event |= 0x1;
    }

    RTOS_ERR err;
//        OS_FLAGS  flags;
    OSFlagPost(&btn_event_flag_grp,
             event,
             OS_OPT_POST_FLAG_SET,
             &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * @brief GPIO_EVEN Handler
 * Interrupt Service Routine for even GPIO pins
 */
void GPIO_EVEN_IRQHandler(void)
{
    GPIO_IRQHandler();
}

/**
 * @brief GPIO_ODD Handler
 * Interrupt Service Routine for odd GPIO pins
 */
void GPIO_ODD_IRQHandler(void)
{
    GPIO_IRQHandler();
}

/**
 * @Brief Samples the status of button 0
 * @return status of button0
 */
unsigned int button0_sample(void)
{
  int status = GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN);
  return status;
}

/**
 * @brief Samples the status of button 1
 * @return status of button1
 */
unsigned int button1_sample(void)
{
  int status = GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN);
  return status;
}

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/**
 * Callback for OS Timer used for angle task
 * @param p_tmr
 * @param p_arg
 */
void angle_timerCallback(void *p_tmr, void *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;

  OSSemPost(&angle_timer_semaphore,
            OS_OPT_POST_ALL,
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * Callback for OS Timer used for physics task
 * @param p_tmr
 * @param p_arg
 */
void physics_timerCallback(void *p_tmr, void *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;

  OSSemPost(&physics_timer_semaphore,
            OS_OPT_POST_ALL,
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * Callback for OS Timer used for LED1 task
 * @param p_tmr
 * @param p_arg
 */
void led1_timerCallback(void *p_tmr, void *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;

  OSSemPost(&led1_timer_semaphore,
            OS_OPT_POST_ALL,
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * Callback for OS Timer used for LED1 task for oneshot timer
 * @param p_tmr
 * @param p_arg
 */
void led1_oneshot_timerCallback(void *p_tmr, void *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;

  if(!gameFlag){
      GPIO_PinOutClear(LED1_port, LED1_pin);
  }
  else{
      GPIO_PinOutClear(LED0_port, LED0_pin);
  }

  OSTmrDel(&led1_oneshot_timer,
           &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * Initializes all tasks and Resources
 */
void tasks_init(void)
{
  RTOS_ERR err;
  uint32_t status;

  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&glibContext);
  EFM_ASSERT(status == GLIB_OK);

  glibContext.backgroundColor = White;
  glibContext.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&glibContext);

  /* Use Narrow font */
  GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);

  NVIC_EnableIRQ(GPIO_ODD_IRQn);
  NVIC_EnableIRQ(GPIO_EVEN_IRQn);
  GPIO_IntConfig(BTN0_port, BTN0_pin, false, true, true);
  GPIO_IntConfig(BTN1_port, BTN1_pin, false, true, true);

  OSFlagCreate(&btn_event_flag_grp,
               "Button Event Flag Group",
               0,
               &err);

  // Create LCD Task
  OSTaskCreate(&lcd_tcb,
               "lcd task",
               lcd_task,
               DEF_NULL,
               LCD_TASK_PRIO,
               &lcd_stack[0],
               (LCD_TASK_STACK_SIZE / 10u),
               LCD_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSSemCreate(&angle_timer_semaphore,
              "Angle Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&angle_timer,
             "Angler Timer",
             0,
             1,
             OS_OPT_TMR_PERIODIC,
             &angle_timerCallback,
             NULL,
             &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSSemCreate(&physics_timer_semaphore,
              "Physics Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&physics_timer,
             "Physics Timer",
             0,
             1,
             OS_OPT_TMR_PERIODIC,
             &physics_timerCallback,
             NULL,
             &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSSemCreate(&led1_timer_semaphore,
              "LED1 Timer Semaphore",
              0,
              &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&led1_timer,
             "LED1 Timer",
             0,
             10,
             OS_OPT_TMR_PERIODIC,
             &led1_timerCallback,
             NULL,
             &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&angle_tcb,
               "angle task",
               angle_task,
               DEF_NULL,
               ANGLE_TASK_PRIO,
               &angle_stack[0],
               (ANGLE_TASK_STACK_SIZE / 10u),
               ANGLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSMutexCreate(&angle_mutex,
                "Angle Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&thrust_tcb,
               "thrust task",
               thrust_task,
               DEF_NULL,
               THRUST_TASK_PRIO,
               &thrust_stack[0],
               (THRUST_TASK_STACK_SIZE / 10u),
               THRUST_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSMutexCreate(&thrust_mutex,
                "Thrust Mutex",
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&physics_tcb,
               "physics task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &physics_stack[0],
               (PHYSICS_TASK_STACK_SIZE / 10u),
               PHYSICS_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&led0_tcb,
               "led0 task",
               led0_task,
               DEF_NULL,
               LED0_TASK_PRIO,
               &led0_stack[0],
               (LED0_TASK_STACK_SIZE / 10u),
               LED0_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&led1_tcb,
               "led1 task",
               led1_task,
               DEF_NULL,
               LED1_TASK_PRIO,
               &led1_stack[0],
               (LED1_TASK_STACK_SIZE / 10u),
               LED1_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&idle_tcb,
               "idle task",
               idle_task,
               DEF_NULL,
               IDLE_TASK_PRIO,
               &idle_stack[0],
               (IDLE_TASK_STACK_SIZE / 10u),
               IDLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/**
 * LCD Task
 * @param arg
 */
static void lcd_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;

    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        GPIO_PinOutToggle(LED0_port, LED0_pin);

        OSMutexPend(&angle_mutex,
                       0,
                       OS_OPT_PEND_BLOCKING,
                       DEF_NULL,
                       &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        ship_angle current_angle = angle_data.current_angle;

        OSMutexPost(&angle_mutex,
                    OS_OPT_NONE,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSMutexPend(&thrust_mutex,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        gameFlag = check_endgame();

        if (!gameFlag){
            GLIB_clear(&glibContext);

            switch(current_angle){
              case straight_up:
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos - 1, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos + 1, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos - 1);
                  break;
              case left:
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos - 1, thrust_data.y_pos-1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos + 1, thrust_data.y_pos + 1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos + 1, thrust_data.y_pos - 1);
                  break;
              case hard_left:
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos + 1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos + 1, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos - 1);
                  break;
              case hard_right:
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos + 1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos - 1, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos - 1);
                  break;
              case right:
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos - 1, thrust_data.y_pos-1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos, thrust_data.y_pos);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos - 1, thrust_data.y_pos + 1);
                  GLIB_drawPixel(&glibContext, thrust_data.x_pos + 1, thrust_data.y_pos - 1);
                  break;
              default:
                  break;
            }

            if (!thrust_data.blackout){
                GLIB_drawStringOnLine(&glibContext,
                                      "Healthy",
                                       0,
                                       GLIB_ALIGN_LEFT,
                                       0,
                                       0,
                                       true);
            }
            else{
                GLIB_drawStringOnLine(&glibContext,
                                      "Blackout",
                                       0,
                                       GLIB_ALIGN_LEFT,
                                       0,
                                       0,
                                       true);
            }

        }

        else{
            if(thrust_data.y_pos >= 128 && thrust_data.y_velo >= MAX_VERT_LANDING_SPEED
                && (thrust_data.x_velo <= MAX_HOR_LANDING_SPEED || thrust_data.x_velo >= -1 * MAX_HOR_LANDING_SPEED)){
                GLIB_drawStringOnLine(&glibContext,
                                      "Successful\n Landing",
                                      4,
                                      GLIB_ALIGN_CENTER,
                                      0,
                                      0,
                                      true);
            }
            else{
                GLIB_drawStringOnLine(&glibContext,
                                      "GAME OVER",
                                      4,
                                      GLIB_ALIGN_CENTER,
                                      0,
                                      0,
                                      true);
            }


        }

        DMD_updateDisplay();

        OSMutexPost(&thrust_mutex,
                    OS_OPT_NONE,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }

}

/**
 * Angle Task
 * @param arg
 */
static void angle_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;

    CAPSENSE_Init();

    angle_data.current_angle = straight_up;

    OSTmrStart(&angle_timer,
               &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    while (1)
      {
        OSSemPend(&angle_timer_semaphore,
                  0,
                  OS_OPT_PEND_BLOCKING,
                  DEF_NULL,
                  &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        CAPSENSE_Sense();
        position = CAPSENSE_getSliderPosition();

        OSMutexPend(&angle_mutex,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSMutexPend(&thrust_mutex,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        if(!thrust_data.blackout){
          set_angle(position);
        }

        OSMutexPost(&thrust_mutex,
                   OS_OPT_NONE,
                   &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSMutexPost(&angle_mutex,
                   OS_OPT_NONE,
                   &err);
       EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}

/**
 * Thrust Task
 * @param arg
 */
static void thrust_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    thrust_data.thrust_value = 0;
    thrust_data.x_pos = GRAPH_XLIM / 2;
    thrust_data.y_pos = 0;
    thrust_data.x_velo = INTL_VELO_X;
    thrust_data.y_velo = INTL_VELO_Y;
    thrust_data.fuel_mass = INTL_FUEL_MASS;
    thrust_data.blackout =  false;
    thrust_data.blackout_time = BLACKOUT_DUR;

    RTOS_ERR err;
    while (1)
    {
        OSFlagPend(&btn_event_flag_grp,
                   0x3,
                   0,
                   OS_OPT_PEND_FLAG_SET_ANY | OS_OPT_PEND_BLOCKING | OS_OPT_PEND_FLAG_CONSUME,
                   DEF_NULL,
                   &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        button0 = !button0_sample();
        button1 = !button1_sample();

        OSMutexPend(&thrust_mutex,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        if(!thrust_data.blackout){
          set_thrust(button0, button1);
        }

        OSMutexPost(&thrust_mutex,
                   OS_OPT_NONE,
                   &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    }
}

/**
 * Physics Task
 * @param arg
 */
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    double current_x_velo = 0.0;
    double current_y_velo = 0.0;
    int current_x_pos = 0;
    int current_y_pos = 0;
    int current_thrust = 0;
    double current_fuel_mass = 0.0;

    OSTmrStart(&physics_timer,
               &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    while (1)
    {
//        OSTimeDly(1000, OS_OPT_TIME_DLY, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        if(!gameFlag){
          OSSemPend(&physics_timer_semaphore,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          time ++;

          OSMutexPend(&angle_mutex,
                     0,
                     OS_OPT_PEND_BLOCKING,
                     DEF_NULL,
                     &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          ship_angle current_angle = angle_data.current_angle;

          OSMutexPost(&angle_mutex,
                      OS_OPT_NONE,
                      &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          OSMutexPend(&thrust_mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          current_x_velo = thrust_data.x_velo;
          current_x_pos = thrust_data.x_pos;
          current_y_velo = thrust_data.y_velo;
          current_y_pos = thrust_data.y_pos;
          current_thrust = thrust_data.thrust_value;
          current_fuel_mass = thrust_data.fuel_mass;

          OSMutexPost(&thrust_mutex,
                      OS_OPT_NONE,
                      &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          if (current_thrust == 0){
                  current_y_velo += GRAVITY * 0.1;
          }

          else if (current_fuel_mass > 0){
              switch (current_angle){
                case straight_up:
                  current_y_velo += ((current_thrust / 40 * CONVERSION_EFFICIENCY) + GRAVITY) * 0.1;
                  break;
                case left:
                  current_y_velo += ((current_thrust / 40 * CONVERSION_EFFICIENCY) * 0.5 + GRAVITY) * 0.1;
                  current_x_velo += ((current_thrust / 40 * CONVERSION_EFFICIENCY) * 0.5) * 0.1;
                  break;
                case hard_left:
                  current_x_velo += ((current_thrust / 40 * CONVERSION_EFFICIENCY*2)) * 0.1;
                  break;
                case right:
                  current_y_velo += ((current_thrust / 40 * CONVERSION_EFFICIENCY) * 0.5 + GRAVITY) * 0.1;
                  current_x_velo -= ((current_thrust / 40 * CONVERSION_EFFICIENCY) * 0.5) * 0.1;
                  break;
                case hard_right:
                  current_x_velo -= ((current_thrust / 40 * CONVERSION_EFFICIENCY*2)) * 0.1;
                  break;
                default:
                  break;
              }

              current_fuel_mass -= current_thrust / 40 * 10;
          }


          current_y_pos += find_posQuanta(current_y_velo);
          current_x_pos += find_posQuanta(current_x_velo);

          OSMutexPend(&thrust_mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

          thrust_data.x_velo = current_x_velo;
          thrust_data.x_pos = current_x_pos;
          thrust_data.y_velo = current_y_velo;
          thrust_data.y_pos = current_y_pos;
          thrust_data.fuel_mass = current_fuel_mass;

          if (time % 10 == 0){ // only checked each second
              if (thrust_data.y_velo <= BLACKOUT_VELO){
                  thrust_data.blackout = true;
              }

              if (thrust_data.blackout){
                  thrust_data.blackout_time--;
                  if (thrust_data.blackout_time == 0){
                      thrust_data.blackout =  false;
                      thrust_data.blackout_time = BLACKOUT_DUR;
                  }
              }
          }

          OSMutexPost(&thrust_mutex,
                      OS_OPT_NONE,
                      &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        else{
            OSTimeDly(10, OS_OPT_TIME_DLY, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }
}

/**
 * LED0 Task
 * @param arg
 */
static void led0_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    while (1)
    {
        if (gameFlag){
            OSSemPend(&led1_timer_semaphore,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            GPIO_PinOutSet(LED0_port, LED0_pin);

            OSTmrCreate(&led1_oneshot_timer,
                       "LED1 one shot Timer",
                       5,
                       0,
                       OS_OPT_TMR_ONE_SHOT,
                       &led1_oneshot_timerCallback,
                       NULL,
                       &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            OSTmrStart(&led1_oneshot_timer,
                       &err);
        }

        else{
            OSTimeDly(10, OS_OPT_TIME_DLY, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }
}

/**
 * LED1 Task
 * @param arg
 */
static void led1_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;



    OSTmrStart(&led1_timer,
               &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    while (1)
    {
//        OSTimeDly(1000, OS_OPT_TIME_DLY, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSSemPend(&led1_timer_semaphore,
                  0,
                  OS_OPT_PEND_BLOCKING,
                  DEF_NULL,
                  &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSMutexPend(&thrust_mutex,
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        current_thrust = thrust_data.thrust_value;

        if (current_thrust != 0 && !gameFlag){
            GPIO_PinOutSet(LED1_port, LED1_pin);

            OSTmrCreate(&led1_oneshot_timer,
                       "LED1 one shot Timer",
                       current_thrust / 40,
                       0,
                       OS_OPT_TMR_ONE_SHOT,
                       &led1_oneshot_timerCallback,
                       NULL,
                       &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            OSTmrStart(&led1_oneshot_timer,
                       &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }

        else{
            GPIO_PinOutClear(LED1_port, LED1_pin);
        }
        OSMutexPost(&thrust_mutex,
                   OS_OPT_NONE,
                   &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    }
}

/**
 * Idle Task. Enters EM1 to save energy.
 * @param arg
 */
static void idle_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  while(1){
      EMU_EnterEM1();
      OSTimeDly(100, OS_OPT_TIME_DLY, &err);
  }
}

/**
 * Helper Function to set thrust in thrust_data struct. Sets based on button input
 * @param button0
 * @param button1
 * @return
 */
int set_thrust(int button0, int button1){
    if (button0){
        if (thrust_data.thrust_value != MAX_THRUST){
            thrust_data.thrust_value += 40;
        }
    }

    if (button1){
        if (thrust_data.thrust_value != 0){
            thrust_data.thrust_value -= 40;
        }
    }

    return thrust_data.thrust_value;
}

/**
 * Converts CAPSENSE input position to immediate ship angle.
 * @param position
 * @return
 */
ship_angle set_angle(int position){
  if (position <= 11 && position >= 0){
      angle_data.current_angle = hard_left;
  }
  else if (position > 11 && position <= 22){
      angle_data.current_angle = left;
  }
  else if (position > 22 && position <= 33){
      angle_data.current_angle = right;
  }
  else if (position > 33 && position <= 44){
      angle_data.current_angle = hard_right;
  }
  else{
      angle_data.current_angle = straight_up;
  }

  return angle_data.current_angle;
}

/**
 * Checks bounds of x and y positions to determine end game condition
 */
bool check_endgame(){
  if (thrust_data.x_pos < 0 || thrust_data.x_pos >= GRAPH_XLIM
      || thrust_data.y_pos < 0 || thrust_data.y_pos >= GRAPH_YLIM){
      return true;
  }
  return false;
}

/**
 * Determines line change quantum based on current velocity.
 * @param velocity
 * @return
 */
int find_posQuanta(double velocity){
    if (velocity <= 65000 && velocity > 52000){
        return -4;
    }

    else if (velocity <= 52000 && velocity > 39000){
        return -3;
    }

    else if (velocity <= 39000 && velocity > 26000){
        return -2;
    }

    else if (velocity <= 26000 && velocity > 13000){
        return -1;
    }
    else if (velocity <= 13000 && velocity > 0 ){
        return 0;
    }

    else if (velocity <= 0 && velocity > -13000){
        return 0;
    }

    else if (velocity <= -13000 && velocity > -26000){
        return 1;
    }

    else if (velocity <= -26000 && velocity > -39000){
        return 2;
    }

    else if (velocity<= -39000 && velocity > -52000){
        return 3;
    }

    else{
        return 4;
    }
}
